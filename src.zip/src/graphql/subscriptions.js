/* eslint-disable */
// this is an auto generated file. This will be overwritten

export const onCreatePost = /* GraphQL */ `
  subscription OnCreatePost {
    onCreatePost {
      id
      name
      team
      project
      vertical
      date
      program
      contentowner
      tags
      image
      createdAt
      updatedAt
      owner
    }
  }
`;
export const onUpdatePost = /* GraphQL */ `
  subscription OnUpdatePost {
    onUpdatePost {
      id
      name
      team
      project
      vertical
      date
      program
      contentowner
      tags
      image
      createdAt
      updatedAt
      owner
    }
  }
`;
export const onDeletePost = /* GraphQL */ `
  subscription OnDeletePost {
    onDeletePost {
      id
      name
      team
      project
      vertical
      date
      program
      contentowner
      tags
      image
      createdAt
      updatedAt
      owner
    }
  }
`;
